#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
#   ANSI CODE   ##################################################################
Black="\033[0;30m"
Red="\033[0;31m"
Green="\033[0;32m"
Blue="\033[0;34m"
Purple="\033[0;35m"
Cyan="\033[0;36m"
Yellow="\033[1;33m"
White="\033[1;37m"
NC="\033[0m"
############################################################################
ddd=$(date +%j)
clear
tput cup 5 0 
echo -e "${Yellow}+${Purple}-------------------------------------------${Yellow}+"
tput cup 6 0
echo -e "   ${Cyan}>>> ${Yellow}1${Blue})${Green} "
tput cup 7 0
echo -e "   ${Cyan}>>> ${Yellow}1${Blue})${Green} "
tput cup 8 0
echo -e "   ${Cyan}>>> ${Yellow}1${Blue})${Green} "
tput cup 9 0
echo -e "${Yellow}+${Purple}-------------------------------------------${Yellow}+"
tput cup 10 10
echo -e "|"
tput cup 10 33
echo -e "|"
tput cup 0 0
echo -e "${Yellow}+${Purple}-------------------------------------------${Yellow}+"
tput cup 1 0
echo -e "${Green}     Parsing Stanford Encyclopedia"
tput cup 11 10
echo -e "${Yellow}+${Purple}----------------------${Yellow}+${White}"
tput cup 10 17
read abc
