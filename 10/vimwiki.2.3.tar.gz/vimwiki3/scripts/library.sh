. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/inpath
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/validalnum
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/normdate
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/nicenumber
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/validint
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/validfloat
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/valid-date
. `dirname "$(readlink -f "${BASH_SOURCE[0]}")"`/echon
