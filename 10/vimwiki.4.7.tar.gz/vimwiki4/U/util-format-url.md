# @aws-sdk/util-format-url

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-format-url/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-format-url)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-format-url.svg)](https://www.npmjs.com/package/@aws-sdk/util-format-url)
