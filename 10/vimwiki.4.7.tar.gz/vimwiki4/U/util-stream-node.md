# @aws-sdk/util-stream-node

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-stream-node/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-stream-node)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-stream-node.svg)](https://www.npmjs.com/package/@aws-sdk/util-stream-node)

Package with utilities to operate on Node.JS streams.

> An internal package

## Usage

You probably shouldn't, at least directly.
