# @aws-sdk/util-stream-browser

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-stream-browser/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-stream-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-stream-browser.svg)](https://www.npmjs.com/package/@aws-sdk/util-stream-browser)

Package with utilities to operate on browser streams.

> An internal package

## Usage

You probably shouldn't, at least directly.
