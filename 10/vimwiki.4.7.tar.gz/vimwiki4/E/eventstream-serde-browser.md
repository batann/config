# @aws-sdk/eventstream-serde-browser

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/eventstream-serde-browser/latest.svg)](https://www.npmjs.com/package/@aws-sdk/eventstream-serde-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/eventstream-serde-browser.svg)](https://www.npmjs.com/package/@aws-sdk/eventstream-serde-browser)

> An internal package

## Usage

You probably shouldn't, at least directly.
