# @aws-sdk/types

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/types/latest.svg)](https://www.npmjs.com/package/@aws-sdk/types)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/types.svg)](https://www.npmjs.com/package/@aws-sdk/types)
