# Installation
> `npm install --save @types/d3-scale-chromatic`

# Summary
This package contains type definitions for d3-scale-chromatic (https://github.com/d3/d3-scale-chromatic/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-scale-chromatic.

### Additional Details
 * Last updated: Mon, 20 Nov 2023 23:36:24 GMT
 * Dependencies: none

# Credits
These definitions were written by [Hugues Stefanski](https://github.com/Ledragon), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [Henrique Machado](https://github.com/henriquefm), and [Nathan Bierema](https://github.com/Methuselah96).
