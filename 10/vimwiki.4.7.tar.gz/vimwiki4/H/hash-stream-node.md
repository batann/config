# @aws-sdk/hash-stream-node

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/hash-stream-node/latest.svg)](https://www.npmjs.com/package/@aws-sdk/hash-stream-node)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/hash-stream-node.svg)](https://www.npmjs.com/package/@aws-sdk/hash-stream-node)

A utility for calculating the hash of Node.JS readable streams.

> An internal package

## Usage

You probably shouldn't, at least directly.
