# @aws-sdk/sha256-blob-browser

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/hash-blob-browser/latest.svg)](https://www.npmjs.com/package/@aws-sdk/hash-blob-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/hash-blob-browser.svg)](https://www.npmjs.com/package/@aws-sdk/hash-blob-browser)

> An internal package

## Usage

You probably shouldn't, at least directly.
