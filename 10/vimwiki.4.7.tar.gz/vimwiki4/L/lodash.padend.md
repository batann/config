# lodash.padend v4.6.1

The [lodash](https://lodash.com/) method `_.padEnd` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash.padend
```

In Node.js:
```js
var padEnd = require('lodash.padend');
```

See the [documentation](https://lodash.com/docs#padEnd) or [package source](https://github.com/lodash/lodash/blob/4.6.1-npm-packages/lodash.padend) for more details.
