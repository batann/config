## Contributed Commands

Although these commands are available as part of the official
**yadm** source tree, they have a somewhat different status. The intention is to
keep interesting and potentially useful commands here, building a library of
examples that might help others.

I recommend *careful review* of any code from here before using it. No
guarantees of code quality is assumed.
