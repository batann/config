# @aws-sdk/md5-js

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/md5-js/latest.svg)](https://www.npmjs.com/package/@aws-sdk/md5-js)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/md5-js.svg)](https://www.npmjs.com/package/@aws-sdk/md5-js)

> An internal package

## Usage

You probably shouldn't, at least directly.
