# @aws-sdk/middleware-flexible-checksums

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/middleware-flexible-checksums/latest.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-flexible-checksums)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/middleware-flexible-checksums.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-flexible-checksums)

This package provides AWS SDK for JavaScript middleware that applies a checksum
of the request body as a header.
