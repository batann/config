# @aws-sdk/xml-builder

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/xml-builder/latest.svg)](https://www.npmjs.com/package/@aws-sdk/xml-builder)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/xml-builder.svg)](https://www.npmjs.com/package/@aws-sdk/xml-builder)

> An internal package

## Usage

You probably shouldn't, at least directly.
